INSERT INTO users(id, name) VALUES (nextval('hibernate_sequence'), 'Alice');
INSERT INTO users(id, name) VALUES (nextval('hibernate_sequence'), 'Bob');
INSERT INTO users(id, name) VALUES (nextval('hibernate_sequence'), 'Charlie');
