rootProject.name = "vertx-websockets"
