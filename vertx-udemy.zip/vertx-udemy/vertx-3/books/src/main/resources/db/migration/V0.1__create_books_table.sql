CREATE TABLE books (
  ISBN numeric PRIMARY KEY,
  TITLE varchar(100) NOT NULL
);
