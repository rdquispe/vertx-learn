package com.danielprinz.udemy.ping_pong.codec;

public class Pong {
  private String message;

  public Pong() {
  }

  public Pong(final String message) {
    this.message = message;
  }

  public String getMessage() {
    return message;
  }

}
