# Ping-Pong
The ping-pong application demonstrates the basic concepts of Vert.x 3 and asynchronous programming.

* Event Bus communication
* Futures
* Scaling of Verticles
* Testing asynchronous code
