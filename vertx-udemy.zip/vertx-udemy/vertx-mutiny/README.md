# Vertx Mutiny

> Intuitive Event-Driven Reactive Programming Library for Java

Showcase the usage of Mutiny with Vert.x.

* https://smallrye.io/smallrye-mutiny/
* https://smallrye.io/smallrye-mutiny-vertx-bindings
